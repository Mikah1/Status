/*    */ package en.cramped_mikah.status;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ 
/*    */ public enum StatusEnum {
/*  6 */   AFK("001", "AFK", ChatColor.GRAY),
/*  7 */   NEW("002", "New", ChatColor.GREEN),
/*  8 */   SEXY("003", "Sexy", ChatColor.LIGHT_PURPLE),
/*  9 */   RED("004", "Red", ChatColor.RED),
/* 10 */   BLUE("005", "Red", ChatColor.RED),
/* 11 */   GREEN("006", "Green", ChatColor.DARK_GREEN),
/* 12 */   YELLOW("007", "Yellow", ChatColor.YELLOW),
/* 13 */   GOLD("008", "Gold", ChatColor.GOLD),
/* 14 */   BLACK("009", "Black", ChatColor.BLACK),
/* 15 */   BOLD("010", "Fat", ChatColor.WHITE);
/*    */   
/*    */   private String position;
/*    */   
/*    */   private String name;
/*    */   private ChatColor color;
/*    */   
/*    */   StatusEnum(String position, String name, ChatColor color) {
/* 23 */     this.position = position;
/* 24 */     this.name = name;
/* 25 */     this.color = color;
/*    */   }
/*    */   
/*    */   public String getPosition() {
/* 29 */     return this.position;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 33 */     return this.name;
/*    */   }
/*    */   
/*    */   public ChatColor getColor() {
/* 37 */     return this.color;
/*    */   }
/*    */ }


/* Location:              C:\Users\Mikah\Dropbox\My PC (DESKTOP-BU1LQ8U)\Downloads\Status.jar!\en\cramped_mikah\status\StatusEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */